
#!/bin/bash
echo "🚀 Ultimate AutoTrader 설치 중..."
apt update && apt install -y python3
echo "✅ 설치 완료! 이제 python3 autotrade.py로 실행하세요."
