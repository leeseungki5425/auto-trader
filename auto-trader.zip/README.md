
# Ultimate AutoTrader

이 저장소는 Bitget 자동매매를 위한 간단한 예제입니다.  
(실제 API 연결 없이 동작하는 구조로 되어 있습니다)

## 사용 방법

1. 설치:
```bash
chmod +x install.sh
./install.sh
```

2. 실행:
```bash
python3 autotrade.py
```
